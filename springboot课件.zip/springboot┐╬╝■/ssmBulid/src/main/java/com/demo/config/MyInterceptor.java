package com.demo.config;

import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Saturday
 * @create 2020-03-24 12:11
 */
public class MyInterceptor implements HandlerInterceptor {
    // return true;执行下一个拦截器  放行
    // return false;不执行下一个拦截器
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("=====拦截前=====");
        return true;

    }
}
