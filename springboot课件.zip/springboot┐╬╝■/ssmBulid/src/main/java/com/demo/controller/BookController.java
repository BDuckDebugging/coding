package com.demo.controller;

import com.demo.pojo.Books;
import com.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * @author Saturday
 * @create 2020-03-23 0:49
 */
@SuppressWarnings("all")
@Controller
@RequestMapping("/book")
public class BookController {
    // controller 调 service层
    @Autowired
    @Qualifier("BookServiceImpl")
    private BookService bookService;

    //查询全部书籍,并且返回到一个展示书籍页面
    @RequestMapping("/allBook")
    public String index(Model model){
        List<Books> list = bookService.queryAllBooks();
        model.addAttribute("list",list);
        return "allBook";
    }

    //跳转到新增书籍
    @RequestMapping("/toAddBook")
    public String toAddBook(){
        return "addBook";
    }
    //新增书籍
    @PostMapping("/addBook")
    public String addBook(Books books){
        bookService.addBook(books);
        return "redirect:/book/allBook";
    }

    //查询一本书
    @GetMapping("/queryBook")
    public  String queryBook(String bookName,Model model){
        List<Books> list = bookService.queryBookByName(bookName);
        model.addAttribute("list",list);
        return "allBook";
    }
}
