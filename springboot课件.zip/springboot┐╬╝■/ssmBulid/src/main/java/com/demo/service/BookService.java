package com.demo.service;

import com.demo.pojo.Books;
import org.apache.ibatis.annotations.Param;


import java.util.List;

/**
 * @author Saturday
 * @create 2020-03-21 21:09
 */
@SuppressWarnings("all")
public interface BookService {
    // 增加一本书
    int addBook(Books books);
    // 删除一本书
    int deleteBookById(int id);
    // 更新一本书
    int updateBook(Books books);
    // 查询一本书
    Books queryBookById(int id);
    // 查询全部书
    List<Books> queryAllBooks();
    // 模糊查询book
    List<Books> queryBookByName(String bookName);
}
