import com.demo.pojo.Books;
import com.demo.service.BookService;
import com.demo.service.BookServiceImpl;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

/**
 * @author Saturday
 * @create 2020-03-23 1:11
 */
public class TestDemo {
    @Test
    public void test(){

        ApplicationContext context = new ClassPathXmlApplicationContext(
                "applicationContext.xml");
        BookService bookServiceImpl = context.getBean("BookServiceImpl", BookService.class);

        List<Books> list = bookServiceImpl.queryAllBooks();
        for (Books books : list) {
            System.out.println("books = " + books);
        }
    }
}
